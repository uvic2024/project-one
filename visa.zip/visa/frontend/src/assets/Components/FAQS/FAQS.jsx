import { Link } from "react-router-dom";

const FAQS = () => {
    return ( 
        <div className="container">
            <h3 className="text-color-1"><Link >FAQS</Link></h3>
            <div>
            </div>
        </div>
     );
}
 
export default FAQS;